import 'package:bloc/bloc.dart';
import 'package:dio/dio.dart';
import 'package:e_commarcae/core/error/serve_eror.dart';
import 'package:e_commarcae/core/services/api/api_Concumer.dart';
import 'package:e_commarcae/core/services/api/endpoit.dart';
import 'package:e_commarcae/feature/brand/model/brandModel.dart';
import 'package:meta/meta.dart';

part 'brand_state.dart';

class BrandCubit extends Cubit<BrandState> {
  BrandCubit({required this.api}) : super(BrandInitial());
  final ApiConsumer api;

  Map<String, dynamic>? _asMap(dynamic response) {
    final dynamic data = response is Response ? response.data : response;
    return data is Map<String, dynamic> ? data : null;
  }

  Future<void> getCategoriess() async {
    emit(BrandLoading());
    try {
      final response = await api.get(Endpoint.brands);
      final map = _asMap(response);
      final List rawData = (map?['data']) as List? ?? const [];
      final List<Brand> brands = rawData
          .whereType<Map<String, dynamic>>()
          .map(Brand.fromJson)
          .toList();
      emit(BrandSuccess(brands: brands));
    } on ServeEror catch (e) {
      emit(BrandFaliure(errorMessage: e.erorrModel.errorMessage));
    } catch (e) {
      emit(BrandFaliure(errorMessage: e.toString()));
    }
  }
}
