class ProductsModel {
  int id;
  String title;
  String description;
  Category category;
  double price;
  double discountPercentage;
  double rating;
  int stock;
  List<String> tags;
  String brand;
  String sku;
  int weight;
  Dimensions dimensions;
  String warrantyInformation;
  String shippingInformation;
  AvailabilityStatus availabilityStatus;
  List<Review> reviews;
  ReturnPolicy returnPolicy;
  int minimumOrderQuantity;
  Meta meta;
  List<String> images;
  String thumbnail;

  ProductsModel({
    required this.id,
    required this.title,
    required this.description,
    required this.category,
    required this.price,
    required this.discountPercentage,
    required this.rating,
    required this.stock,
    required this.tags,
    required this.brand,
    required this.sku,
    required this.weight,
    required this.dimensions,
    required this.warrantyInformation,
    required this.shippingInformation,
    required this.availabilityStatus,
    required this.reviews,
    required this.returnPolicy,
    required this.minimumOrderQuantity,
    required this.meta,
    required this.images,
    required this.thumbnail,
  });

  factory ProductsModel.fromJson(Map<String, dynamic> json) => ProductsModel(
    id: json["id"] ?? 0,
    title: json["title"] ?? "Unknown Product",
    description: json["description"] ?? "",
    category: categoryValues.map[json["category"]] ?? Category.BEAUTY,
    price: (json["price"] ?? 0.0).toDouble(),
    discountPercentage: (json["discountPercentage"] ?? 0.0).toDouble(),
    rating: (json["rating"] ?? 0.0).toDouble(),
    stock: json["stock"] ?? 0,
    tags: json["tags"] != null ? List<String>.from(json["tags"].map((x) => x.toString())) : [],
    brand: json["brand"] ?? "Generic",
    sku: json["sku"] ?? "",
    weight: json["weight"] ?? 0,
    dimensions: Dimensions.fromJson(json["dimensions"] ?? {}),
    warrantyInformation: json["warrantyInformation"] ?? "",
    shippingInformation: json["shippingInformation"] ?? "",
    availabilityStatus:
        availabilityStatusValues.map[json["availabilityStatus"]] ?? AvailabilityStatus.IN_STOCK,
    reviews: json["reviews"] != null
        ? List<Review>.from(json["reviews"].map((x) => Review.fromJson(x)))
        : [],
    returnPolicy: returnPolicyValues.map[json["returnPolicy"]] ?? ReturnPolicy.NO_RETURN_POLICY,
    minimumOrderQuantity: json["minimumOrderQuantity"] ?? 1,
    meta: Meta.fromJson(json["meta"] ?? {}),
    images: json["images"] != null ? List<String>.from(json["images"].map((x) => x.toString())) : [],
    thumbnail: json["thumbnail"] ?? "",
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "title": title,
    "description": description,
    "category": categoryValues.reverse[category],
    "price": price,
    "discountPercentage": discountPercentage,
    "rating": rating,
    "stock": stock,
    "tags": List<dynamic>.from(tags.map((x) => x)),
    "brand": brand,
    "sku": sku,
    "weight": weight,
    "dimensions": dimensions.toJson(),
    "warrantyInformation": warrantyInformation,
    "shippingInformation": shippingInformation,
    "availabilityStatus": availabilityStatusValues.reverse[availabilityStatus],
    "reviews": List<dynamic>.from(reviews.map((x) => x.toJson())),
    "returnPolicy": returnPolicyValues.reverse[returnPolicy],
    "minimumOrderQuantity": minimumOrderQuantity,
    "meta": meta.toJson(),
    "images": List<dynamic>.from(images.map((x) => x)),
    "thumbnail": thumbnail,
  };
}

enum AvailabilityStatus { IN_STOCK, LOW_STOCK }

final availabilityStatusValues = EnumValues({
  "In Stock": AvailabilityStatus.IN_STOCK,
  "Low Stock": AvailabilityStatus.LOW_STOCK,
});

enum Category { BEAUTY, FRAGRANCES }

final categoryValues = EnumValues({
  "beauty": Category.BEAUTY,
  "fragrances": Category.FRAGRANCES,
});

class Dimensions {
  double width;
  double height;
  double depth;

  Dimensions({required this.width, required this.height, required this.depth});

  factory Dimensions.fromJson(Map<String, dynamic> json) => Dimensions(
    width: (json["width"] ?? 0.0).toDouble(),
    height: (json["height"] ?? 0.0).toDouble(),
    depth: (json["depth"] ?? 0.0).toDouble(),
  );

  Map<String, dynamic> toJson() => {
    "width": width,
    "height": height,
    "depth": depth,
  };
}

class Meta {
  DateTime createdAt;
  DateTime updatedAt;
  String barcode;
  String qrCode;

  Meta({
    required this.createdAt,
    required this.updatedAt,
    required this.barcode,
    required this.qrCode,
  });

  factory Meta.fromJson(Map<String, dynamic> json) => Meta(
    createdAt: DateTime.tryParse(json["createdAt"] ?? "") ?? DateTime.now(),
    updatedAt: DateTime.tryParse(json["updatedAt"] ?? "") ?? DateTime.now(),
    barcode: json["barcode"] ?? "",
    qrCode: json["qrCode"] ?? "",
  );

  Map<String, dynamic> toJson() => {
    "createdAt": createdAt.toIso8601String(),
    "updatedAt": updatedAt.toIso8601String(),
    "barcode": barcode,
    "qrCode": qrCode,
  };
}

enum ReturnPolicy {
  NO_RETURN_POLICY,
  THE_7_DAYS_RETURN_POLICY,
  THE_90_DAYS_RETURN_POLICY,
}

final returnPolicyValues = EnumValues({
  "No return policy": ReturnPolicy.NO_RETURN_POLICY,
  "7 days return policy": ReturnPolicy.THE_7_DAYS_RETURN_POLICY,
  "90 days return policy": ReturnPolicy.THE_90_DAYS_RETURN_POLICY,
});

class Review {
  int rating;
  String comment;
  DateTime date;
  String reviewerName;
  String reviewerEmail;

  Review({
    required this.rating,
    required this.comment,
    required this.date,
    required this.reviewerName,
    required this.reviewerEmail,
  });

  factory Review.fromJson(Map<String, dynamic> json) => Review(
    rating: json["rating"] ?? 0,
    comment: json["comment"] ?? "",
    date: DateTime.tryParse(json["date"] ?? "") ?? DateTime.now(),
    reviewerName: json["reviewerName"] ?? "Anonymous",
    reviewerEmail: json["reviewerEmail"] ?? "",
  );

  Map<String, dynamic> toJson() => {
    "rating": rating,
    "comment": comment,
    "date": date.toIso8601String(),
    "reviewerName": reviewerName,
    "reviewerEmail": reviewerEmail,
  };
}

class EnumValues<T> {
  Map<String, T> map;
  late Map<T, String> reverseMap;

  EnumValues(this.map);

  Map<T, String> get reverse {
    reverseMap = map.map((k, v) => MapEntry(v, k));
    return reverseMap;
  }
}
