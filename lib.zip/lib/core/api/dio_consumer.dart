import 'package:dio/dio.dart';
import 'package:e_commarcae/core/services/api/api_Concumer.dart';
import 'package:e_commarcae/core/services/api/api_interceptor.dart';
import 'package:e_commarcae/core/services/api/endpoit.dart';

class DioConsumer extends ApiConsumer {
  final Dio dio;
  DioConsumer({required this.dio}) {
    dio.options.baseUrl = Endpoint.baseurl;
    dio.interceptors.add(ApiInterceptor());
    dio.interceptors.add(LogInterceptor(responseBody: true, requestHeader: true));
  }

  @override
  Future<dynamic> get(String path, {Object? data, Map<String, dynamic>? quary}) async {
    try {
      final response = await dio.get(path, data: data, queryParameters: quary);
      return response.data;
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<dynamic> post(String path, {Object? data, Map<String, dynamic>? quary}) async {
    try {
      final response = await dio.post(path, data: data, queryParameters: quary);
      return response.data;
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<dynamic> put(String path, {Object? data, Map<String, dynamic>? quary}) async {
    try {
      final response = await dio.put(path, data: data, queryParameters: quary);
      return response.data;
    } catch (e) {
      rethrow;
    }
  }

  @override
  Future<dynamic> delet(String path, {Object? data, Map<String, dynamic>? quary}) async {
    try {
      final response = await dio.delete(path, data: data, queryParameters: quary);
      return response.data;
    } catch (e) {
      rethrow;
    }
  }
}
